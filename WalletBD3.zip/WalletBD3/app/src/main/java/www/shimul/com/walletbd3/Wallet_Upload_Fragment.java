package www.shimul.com.walletbd3;


import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import static android.app.Activity.RESULT_OK;


public class Wallet_Upload_Fragment extends Fragment implements View.OnClickListener {


    public Wallet_Upload_Fragment() {
        // Required empty public constructor

        //button=find
    }

    EditText wCode,wTitle,wDes;
    Button wUploadBtn;
    ImageView wImg_one;
    private static final int GALLERY_REQUEST=1;
    private Uri mImageUri;

    //int imageV=0;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_wallet__upload_, container, false);
        wUploadBtn=view.findViewById(R.id.walletUploadBtnId);
        wUploadBtn.setOnClickListener(this);

        //upload taks
        wCode=view.findViewById(R.id.walletPCodeId);
        wTitle=view.findViewById(R.id.walletPTitleId);
        wDes=view.findViewById(R.id.walletPDes);

        wImg_one=view.findViewById(R.id.wImgId1);
        wImg_one.setOnClickListener(this);

        return view;

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.walletUploadBtnId:


                String code=wCode.getText().toString().toString().trim();
                String title=wTitle.getText().toString().toString().trim();
                String des=wDes.getText().toString().toString().trim();

                if (code.isEmpty()){
                    wCode.setError("Enter Your Product Code");
                    wCode.requestFocus();
                    return;
                }
                else if (title.isEmpty()){
                    wTitle.setError("Enter Your Product Title");
                    wTitle.requestFocus();
                    return;
                }

                else if (des.isEmpty()){
                    wDes.setError("Enter Your Product Description");
                    wDes.requestFocus();
                    return;
                }



                else {

                    Intent intent=new Intent(getActivity(),MainActivity.class);
                    startActivity(intent);
                    break;
                    //Toast.makeText(getActivity(), "Image Not Selected", Toast.LENGTH_SHORT).show();
                }






            case R.id.wImgId1:
                //imageV=2;
                openFileChooser();
                break;

        }
    }



    //---------for image Selected File chooser---------------
    private void openFileChooser()
    {
        Intent galleryIntent=new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,GALLERY_REQUEST);
        //break;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {


        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==GALLERY_REQUEST && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            mImageUri=data.getData();
            //Picasso.with(this).load(mImageUri).into(mSelectImage);

            Picasso.with(getActivity()).load(mImageUri).networkPolicy(NetworkPolicy.OFFLINE).into(wImg_one);
        }
    }



}
