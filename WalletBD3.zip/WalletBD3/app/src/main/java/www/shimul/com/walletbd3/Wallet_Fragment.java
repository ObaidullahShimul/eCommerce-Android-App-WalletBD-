package www.shimul.com.walletbd3;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

public class Wallet_Fragment extends Fragment{

    private static final String TAG="Wallet Fragment";

    //----------grid view------------
    GridView walletGrid;
    private String[] studentnames;
    private int[] spic ={R.drawable.wallet_img,R.drawable.wallet_img,
            R.drawable.wallet_img, R.drawable.italyflag,R.drawable.wallet_img,
            R.drawable.italyflag,R.drawable.wallet_img,R.drawable.italyflag,
            R.drawable.wallet_img,R.drawable.italyflag,R.drawable.wallet_img};


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.wallet_fragment,container,false);

        walletGrid=(GridView) view.findViewById(R.id.walletGridId);
        studentnames=getResources().getStringArray(R.array.stdent_names);

        //-----for custorm adapter------
        //CustomAdapter adapter=new CustomAdapter(this,studentnames,spic);
        CustomAdapter adapter=new CustomAdapter(getActivity(),studentnames,spic);
        walletGrid.setAdapter(adapter);

        walletGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String value=studentnames[position];
                //Toast.makeText(Wallet_Fragment.this,value,Toast.LENGTH_SHORT).show();

            }
        });

        return view;

    }

}
